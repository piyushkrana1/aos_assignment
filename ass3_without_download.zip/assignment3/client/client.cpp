#include<bits/stdc++.h>
#include<stdio.h>
#include<unistd.h>
#include<sys/socket.h>
#include<stdlib.h>
#include<netinet/in.h>
#include<string.h>
#include<arpa/inet.h>
#include<pthread.h>

using namespace std;

char peername[50];
int myport;
void * listening_func(void *peer_fd);
void sending_function();
void listening(int listen_socket_fd);
bool loggedin=false;


vector<string>splitstr(string str,char del){

    vector<string>vec;
    string temp="";
    for(int i=0;i<str.length();i++){
        if(str[i]!=':'){
            temp+=str[i];
        }
        else{
        vec.push_back(temp);
        temp="";
        }
    }
    vec.push_back(temp);
    return vec;

}


vector<string> strtovecofstr(string str){
    vector<string>vecstr;
    string temp="";

    for(int i=0;i<str.size();i++){
        if(str[i]!=' '){
            temp=temp+str[i];
        }
        else{
            vecstr.push_back(temp);
            temp="";
        }
    }
    vecstr.push_back(temp);
    return vecstr;
}


vector<string> stringtovectorofstring(string str){
    vector<string>vecstr;
    string temp="";

    for(int i=0;i<str.size();i++){
        if(str[i]!=' '){
            temp=temp+str[i];
        }
        else{
            vecstr.push_back(temp);
            temp="";
        }
    }
    vecstr.push_back(temp);
    return vecstr;
}


void sending_function(){

    char buffer[1500];
    int port;
    printf("port number to send the message:");///need to find out from tracker
    // port=9000;
    scanf("%d",&port);
    int p_s_fd;
    p_s_fd=socket(AF_INET,SOCK_STREAM,0);
    if(p_s_fd<0){
        perror("cant make a new socket\n");
    }

    struct sockaddr_in send_addr;
    send_addr.sin_family=AF_INET;
    send_addr.sin_addr.s_addr=INADDR_ANY;
    send_addr.sin_port=htons(port);
    
    int connectvar=connect(p_s_fd,(struct sockaddr *)&send_addr,sizeof(send_addr));
    if(connectvar<0){
        perror("cant connect");
        return;
    }
    vector<string>commands;
    //sending message with data of port and peer;
    while(true)
    {
        char buffer2[1000]={0};
        char message;
        printf("enter the Command\n");

        scanf("%c",&message);
        scanf("%[^\n]s",buffer2);

        commands=strtovecofstr(string(buffer2));

        if(commands[0]=="login"){
            string ip="0.0.0.0";
            string port="8000";
            string ipport=ip+" "+port;
            string f=string(buffer2)+" "+string(ipport);
            snprintf(buffer2,1000,f.c_str());
        }

        // for(auto i:commands){cout<<i<<" ";}cout<<endl;
        // if(commands[0]=="login"){
        //     loggedin=true;
        //     continue;
        // }
        // if(commands[0]=="login"&&loggedin){
        //     cout<<"already logged in\n"<<flush;
        //     continue;
        // }
        // if(commands[0]!="login"&&commands[0]!="create_user"&&loggedin){
        //     cout<<"PLease login first\n"<<flush;
        //     continue;
        // }
        // if(commands[0]=="logout"){
        //     loggedin=false;
        // }
        
        


        // sprintf(buffer,"%s",buffer2);
        send(p_s_fd,buffer2,sizeof(buffer2),0);

        printf("data sent\n");
    }
    close(p_s_fd);

}

//Receiving messages on our port

void funct_client(int acceptvar){

    // cout<<"Im in function client for list\n"<<flush;

    if(acceptvar<0){
        perror("cant accpt");
    }
    vector<string>commands;
    while(true){
        char buffer[1000]={0};
        int valread=read(acceptvar,buffer,1000);

        // cout<<"valread\n"<<valread;
        // printf("%s\n",buffer);
        cout<<string(buffer)<<endl<<flush;
        commands=stringtovectorofstring(string(buffer));
        // for(auto it:commands){
        //     cout<<it<<flush<<endl;
        // }
        commands.clear();
    }


}



void *listening_func(void *arg)
{   
    struct sockaddr_in address;
    int addrlen=sizeof(address);
    char buffer[1024];
    int setopt=1;
    int listen_socket;
    listen_socket=socket(AF_INET,SOCK_STREAM,0);
    if(listen_socket<0){
        perror("socket build failed");
        exit(EXIT_FAILURE);
    }

    if(setsockopt(listen_socket,SOL_SOCKET,SO_REUSEADDR|SO_REUSEPORT,&setopt,sizeof(setopt))){
        perror("socket not set");
        exit(EXIT_FAILURE);
    }

    address.sin_addr.s_addr=INADDR_ANY;
    address.sin_family=AF_INET;
    address.sin_port=htons(myport);

    // if(inet_pton(AF_INET, &peer_ip[0], &address.sin_addr)<=0)  { 
    //     printf("\nInvalid address/ Address not supported \n"); 
    //     return NULL; 
    // }  //when ip adress given by table


    int bindvar=bind(listen_socket,(struct sockaddr*)&address,sizeof(address));
    if(bindvar<0){
        perror("binding failed");
    }   

    int backlog=10;

    int listenvar=listen(listen_socket,backlog);
    if(listenvar<0){
        perror("cant listen");
        exit(EXIT_FAILURE);
    }

    vector<thread>threadvec;

    while(true){
        int acceptvar=accept(listen_socket,(struct sockaddr*)&address,(socklen_t*)(&addrlen));
        if(acceptvar<0){
            perror("cant accpt");
            exit(EXIT_FAILURE);
        }
        thread th(funct_client,acceptvar);

        threadvec.push_back(move(th));
    }
    for(thread &th:threadvec){
        if(th.joinable())
            th.join();
    }
    close(listen_socket);

}



int main(int argc,char const *argv[])
{
    // printf("Enter a name for your peer : ");
    // scanf("%s",peername);
    // peername="client1";

    if(argc!=3){
        cout<<"wrong input\n";
        return -1;
    }
    // myip
    string clientinfo=argv[1];
    string trackerfile=argv[2];

    vector<string>vec=splitstr(clientinfo,':');
    string myip=vec[0];
    myport=stoi(vec[1]);


    printf("port number for the peer: \n");
    cout<<myport<<"\n"<<flush;
    // scanf("%d",&myport);
    // myport=8081;

    //buiilding a socket for comm
    int peer_fd=socket(AF_INET,SOCK_STREAM,0);
    if(peer_fd<0){
        perror("error failed");
        exit(EXIT_FAILURE);
    }
    // struct sockaddr_in address;
    // address.sin_family=AF_INET;
    // address.sin_addr.s_addr=INADDR_ANY;
    // address.sin_port=htons(myport);

    // printf("peers ip adress is %s\n",inet_ntoa(address.sin_addr));
    // printf("my port adress is :%d\n ",(int)ntohs(address.sin_port));

    // int bindvar=bind(peer_fd,(struct sockaddr*)&address,sizeof(address));
    // if(bindvar<0){
    //     perror("cant bind the port :Port not available");
    //     exit(EXIT_FAILURE);
    // }

    // //listening
    // int backlog=10;
    // int listenvar=listen(peer_fd,backlog);
    // if(listenvar<0){
    //     perror("Error in Listening at this port");
    //     exit(EXIT_FAILURE);
    // }

    //now doing main functionality accept and send inside threading

    pthread_t newthread;
    pthread_create(&newthread,NULL,&listening_func,NULL);//always in listening state in back we can say

    // int choice;
    // printf("Enter the commands:\n");
    
    sending_function();


    // close(peer_fd);
    return 0;

}