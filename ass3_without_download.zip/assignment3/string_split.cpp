#include<bits/stdc++.h>
using namespace std;

vector<string>splitstr(string str,char del){

    vector<string>vec;
    string temp="";
    for(int i=0;i<str.length();i++){
        if(str[i]!=':'){
            temp+=str[i];
        }
        else{
        vec.push_back(temp);
        temp="";
        }
    }
    vec.push_back(temp);
    return vec;

}


int main(){

   vector<string>str= splitstr("hi:this:is:piyush:rana a",':');

   for(auto i:str){
        cout<<i<<" ";
   }
   cout<<endl;
   return 0;
}