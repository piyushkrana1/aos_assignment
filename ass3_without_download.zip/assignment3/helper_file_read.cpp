#include<bits/stdc++.h>
using namespace std;


int main(){
    fstream file;
    file.open("./tracker/tracker_info.txt");
    if(!file.is_open()){
        cout<<"error\n";
    }
    string ip,port;
    file>>ip;file>>port;

    cout<<"ip "<<ip<<" "<<"port "<<port<<endl;

    return 0;

}