#include<bits/stdc++.h>
#include <netinet/in.h>
#include <stdio.h>
#include<pthread.h>
#include<thread>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include<ctime>


//definations

#define DTTMFMT "%Y-%m-%d %H:%M:%S "
#define DTTMSZ 21
#define tracker1_port 9000
using namespace std;

static char *getDtTm (char *buff) {
    time_t t = time (0);
    strftime (buff, DTTMSZ, DTTMFMT, localtime (&t));
    return buff;
}
void logwriter(const string &s){
    FILE *fp;
    char dt[DTTMSZ];
    string filename="logfile.txt";
    fp=fopen(filename.c_str(),"at");
    getDtTm(dt);
    fprintf(fp,dt);
    fprintf(fp,s.c_str());
    fclose(fp);
}

void funct_clients(int acceptvar){

}

int main(){
    // string messages="log file successfully created";
    // logwriter(messages);
   
    struct  sockaddr_in addr;
    int addrlen=sizeof(addr);
    char buffer[1024];
    int setopt=1;
    char *message="acknowledgement";

    //make socket
   int tracker_fd=socket(AF_INET,SOCK_STREAM,0);
    if(tracker_fd<0){
        perror("socket build failed");
        exit(EXIT_FAILURE);
    }

    //attaching or saving socket; forcefully
    if(setsockopt(tracker_fd,SOL_SOCKET,SO_REUSEADDR|SO_REUSEPORT,&setopt,sizeof(setopt))){
        perror("socket not set");
        exit(EXIT_FAILURE);
    }
    logwriter("thread created");
    addr.sin_addr.s_addr=INADDR_ANY;
    addr.sin_family=AF_INET;
    addr.sin_port=htons(tracker1_port);

    //bind to address

    int bindvar=bind(tracker_fd,(struct sockaddr*)&addr,sizeof(addr));
    if(bindvar<0){
        perror("binding failed");
    }   

    //listen with backlog =10
    int backlog=10;

    int listenvar=listen(tracker_fd,backlog);
    if(listenvar<0){
        perror("cant listen");
        exit(EXIT_FAILURE);
    }

    //accepting to listen
    vector<thread>threadvec;
    while(true){

        int acceptvar=accept(tracker_fd,(struct sockaddr*)&addr,(socklen_t*)(&addrlen));
        if(acceptvar<0){
            perror("cant accpt");
            exit(EXIT_FAILURE);
        }

        threadvec.push_back(thread(funct_clients,acceptvar));
        //this work to do in thread function which handles all the clients  
        // int valread=read(acceptvar,buffer,1024);
        // printf("%s\n",buffer);
        // send(acceptvar,message,strlen(message),0);
        // printf("hello sent to client\n");

    }


    // shutdown(tracker_fd,SHUT_RDWR); used to block connection rdwr is like one way or other
    //close fully destroy the connections;
    return 0;
}   