#include<bits/stdc++.h>
#include <netinet/in.h>
#include <stdio.h>
#include<pthread.h>
#include<thread>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include<ctime>
#include<sys/stat.h>
#include<fcntl.h>


//definations

#define DTTMFMT "%Y-%m-%d %H:%M:%S "
#define DTTMSZ 21
#define tracker1_port 9000

// #define filemaap unordered_map<string,vector<string>v

using namespace std;


static char *getDtTm (char *buff) {
    time_t t = time (0);
    strftime (buff, DTTMSZ, DTTMFMT, localtime (&t));
    return buff;
}
void logwriter(const string &s){
    FILE *fp;
    char dt[DTTMSZ];
    string filename="logfile.txt";
    fp=fopen(filename.c_str(),"at");
    getDtTm(dt);
    fprintf(fp,dt);
    fprintf(fp,s.c_str());
    fclose(fp);
}
unordered_map<string,string>user_password;
unordered_map<string,vector<string>>client_ip_port_map;
unordered_map<string,bool>loggedin_map;
unordered_map<string,unordered_set<string>>groupmember_map;
unordered_map<string,string>groupadmin_map;//group ==>>admin
unordered_map<string,unordered_set<string>>grouppendingrequest_map;


unordered_map<string,unordered_map <string,unordered_map<string,vector<string>>>>fileupload_map;
    vector<string>filedetails_of_member;
    unordered_map<string,vector<string>>user_to_filedetails;
    unordered_map<string,unordered_map<string,vector<string>>>file_to_inside;

// unordered_map<s
// gid==>list(of files)

vector<string> stringtovectorofstring(string str){
    vector<string>vecstr;
    string temp="";

    for(int i=0;i<str.size();i++){
        if(str[i]!=' '){
            temp=temp+str[i];
        }
        else{
            vecstr.push_back(temp);
            temp="";
        }
    }
    vecstr.push_back(temp);
    return vecstr;
}

vector<string>splitstr(string str){

    vector<string>vec;
    string temp="";
    for(int i=0;i<str.length();i++){
        if(str[i]!=':'){
            temp+=str[i];
        }
        else{
        vec.push_back(temp);
        temp="";
        }
    }
    vec.push_back(temp);
    return vec;

}

string get_file_name(string s){
    string var="";
    for(auto &i:s){
        if(i=='/'){
            var="";
        }
        else{
            var=var+i;
        }
    }
    return var;
}




void create_user_funct(string name,string password){
    if(user_password.find(name)!=user_password.end()){
        cout<<"user already exists\n";return;
    }
    user_password[name]=password;

    cout<<"user successfully created\n";
}


int login(string name,string password){
    if(user_password.find(name)!=user_password.end()){
        if(password!=user_password[name]){
            cout<<"wrong password\n";
            return 0;
        }
        else{
            loggedin_map[name]=true;
            // for(auto i:loggedin_map){
            //     cout<<endl<<i.first<<" "<<i.second<<" "<<endl<<flush;
            // }
            cout<<"Login successfully\n";
            return 1;
        }
    }
    else{
        cout<<"user not found\n";
        return 0;
    }

}


void funct_clients(int acceptvar){

    if(acceptvar<0){
        perror("cant accpt");
    }
    vector<string>commands;
    int flag=0;
    string client_id="";
    string client_gid="";
    while(true){
        char buffer[1000]={0};
        int valread=read(acceptvar,buffer,1000);
        
        // cout<<"asd\n"<<flush;
        commands=stringtovectorofstring(string(buffer));
        if(commands[0]!="login"){
            printf("%s\n",buffer);
        }
        // for(auto i=0;i<commands.size();i++){
        //     cout<<i<<" "<<commands[i]<<endl;
        // }
        if(commands[0]=="create_user"){
            if(commands.size()<3){cout<<"wrong command Again\n"<<flush;continue;}
            create_user_funct(commands[1],commands[2]);
            commands.clear();
            loggedin_map[commands[1]]=false;
        }
        
        if(commands[0]=="login"){
            cout<<commands[0]<<" "<<commands[1]<<" "<<commands[2]<<endl<<flush;
            if(commands.size()<5){cout<<"wrong command Again\n"<<flush;continue;}
            flag=login(commands[1],commands[2]);
            client_id=commands[1];
            string ip=commands[3];
            string port=commands[4];
            vector<string>temp;temp.push_back(ip);temp.push_back(port);
            client_ip_port_map[client_id]=temp;temp.clear();

            // cout<<"ip"<<" "<<ip<<"port"<<" "<<port<<endl;

            // commands.clear();
        }
        
        if(commands[0]=="logout"){
            if(loggedin_map.find(client_id)!=loggedin_map.end()){
                if(loggedin_map[client_id]==true){
                    loggedin_map[client_id]=false;
                    cout<<"Client logged Out"<<flush;
                    flag=0;
                    continue;                
                }
                cout<<"your not logged in\n"<<flush;
            }
            else{
                cout<<"your not a client\n"<<flush;
            }
        }
        
        if(commands[0]=="create_group"){
            if(!flag){cout<<"please login first\n"<<flush;continue;}
            if(commands.size()<2){cout<<"wrong command enter Again\n"<<flush;continue;}
            string groupname=commands[1];
            if(groupmember_map.find(groupname)!=groupmember_map.end()){
                cout<<"group allready exist"<<flush;continue;
            }

            groupadmin_map[groupname]=client_id;
            groupmember_map[groupname].insert(client_id);
            cout<<"group "<<groupname<<" created\n"<<flush;
        }

        if(commands[0]=="leave_group"){
            if(!flag){cout<<"please login first\n"<<flush;continue;}
            if(commands.size()<2){
                cout<<"wrong command enter Again\n"<<flush;
                continue;
            }
            string gid=commands[1];
            if(groupmember_map.find(gid)==groupmember_map.end()){
                cout<<"group dont exist\n"<<flush;
                continue;
            }
            if(groupmember_map[gid].find(client_id)==groupmember_map[gid].end()){
                cout<<"your not in group\n"<<flush;
                continue;
            }
                        //only 1 member
            if(groupmember_map[gid].size()==1&&(groupadmin_map[gid]==client_id)){
                cout<<"You're only member Deleting the group\n"<<flush;
                groupmember_map.erase(gid);
                cout<<"deleting Group\n"<<flush;
                continue;
            }

            if(groupadmin_map[gid]==client_id){
                cout<<"Your admin of this group\n";
            }

            groupmember_map[gid].erase(client_id);
            cout<<"group left successfully";
            //check if he is group admin
           
            for(auto i:groupmember_map[gid]){
                 groupadmin_map[gid]=i;break;
            }
        }

        if(commands[0]=="join_group"){
            if(!flag){cout<<"please login first\n"<<flush;continue;}
            if(commands.size()<2){
                cout<<"wrong command enter Again\n"<<flush;
                continue;
            }
            string gid=commands[1];
            if(groupmember_map.find(gid)==groupmember_map.end()){
                cout<<"group dont exist\n"<<flush;
                continue;
            }
            grouppendingrequest_map[gid].insert(client_id);
        }

        if(commands[0]=="list_requests"){
        
            if(commands.size()<2){
                cout<<"wrong command enter Again\n"<<flush;
                continue;
            }
            string gid=commands[1];
            if(groupmember_map.find(gid)==groupmember_map.end()){
                cout<<"group dont exist\n"<<flush;
                continue;
            }
            for(auto i:grouppendingrequest_map[gid]){
                cout<<i<<endl;
            }
            cout<<flush;
        }

        if(commands[0]=="accept_request"){
            if(!flag){cout<<"please login first\n"<<flush;continue;}
            if(commands.size()<3){
                cout<<"wrong command enter Again\n"<<flush;
                continue;
            }
            string gid=commands[1];
            string user_id=commands[2];
            if(groupadmin_map[gid]!=client_id){
                cout<<"You are not a admin\n"<<flush;
            }
            grouppendingrequest_map[gid].erase(user_id);
            groupmember_map[gid].insert(user_id);
            
        }

        if(commands[0]=="list_groups"){
            for(auto &gidd:groupmember_map){
                    cout<<gidd.first<<endl<<flush;
            }
        }

        if(commands[0]=="gmembershow"){
            for(auto &gidd:groupmember_map){
                for(auto name:gidd.second){
                    cout<<gidd.first<<" "<<name<<" "<<endl<<flush;
                }
            }
        }

        if(commands[0]=="gadminshow"){
            for(auto &gidd:groupadmin_map){
                
                    cout<<gidd.first<<" "<<gidd.second<<" "<<endl<<flush;
            }
        }

        if(commands[0]=="upload_file"){

            vector<string>filedetails_of_member;
            unordered_map<string,vector<string>>user_to_filedetails;
            unordered_map<string,unordered_map<string,vector<string>>>file_to_inside;

            if(!flag){cout<<"please login first\n"<<flush;continue;}
            if(commands.size()<3){
                cout<<"wrong command enter Again\n"<<flush;
                continue;
            }
            string filelocation=commands[1];
            string gid=commands[2];
            string ip=client_ip_port_map[client_id][0];
            string port=client_ip_port_map[client_id][1];
            //check group number;
            if(groupmember_map.find(gid)==groupmember_map.end()){
                cout<<"group dont exist\n"<<flush;
                continue;
            }
            if(groupmember_map[gid].find(client_id)==groupmember_map[gid].end()){
                cout<<"your not in group\n"<<flush;
                continue;
            }
            
            struct stat fileStat;
            char buff[1024]={0};
            char *res=realpath(filelocation.c_str(),buff);
            filelocation=string(buff);


            //upload file 
                string filesize;
                stat(filelocation.c_str(),&fileStat);
                filesize=to_string((int)(fileStat.st_size));
                filedetails_of_member.push_back(ip);
                filedetails_of_member.push_back(port);
                filedetails_of_member.push_back(filesize);
                filedetails_of_member.push_back(filelocation);
                user_to_filedetails[client_id]=filedetails_of_member;

                string filename=get_file_name(filelocation);


                file_to_inside[filename]=user_to_filedetails;
                fileupload_map[gid]=file_to_inside;


                for(auto gid:fileupload_map){
                    
                    for(auto file:gid.second){
                        
                        for(auto mid:file.second){
                            cout<<gid.first<<" ";
                            cout<<file.first<<" ";
                            cout<<mid.first<<" ";
                            for(auto data:mid.second){
                                cout<<data<<" ";
                            }
                            cout<<endl;
                        }
                    }
                }
        }


        commands.clear();
        // break;
    }
}

int main(){
    // string messages="log file successfully created";
    // logwriter(messages);
   
    struct  sockaddr_in addr;
    int addrlen=sizeof(addr);
    char buffer[1024];
    int setopt=1;
    // char *message="acknowledgement";

    //make socket
   int tracker_fd=socket(AF_INET,SOCK_STREAM,0);
    if(tracker_fd<0){
        perror("socket build failed");
        exit(EXIT_FAILURE);
    }

    //attaching or saving socket; forcefully
    if(setsockopt(tracker_fd,SOL_SOCKET,SO_REUSEADDR|SO_REUSEPORT,&setopt,sizeof(setopt))){
        perror("socket not set");
        exit(EXIT_FAILURE);
    }
    logwriter("thread created");
    addr.sin_addr.s_addr=INADDR_ANY;
    addr.sin_family=AF_INET;
    addr.sin_port=htons(tracker1_port);

    //bind to address

    int bindvar=bind(tracker_fd,(struct sockaddr*)&addr,sizeof(addr));
    if(bindvar<0){
        perror("binding failed");
    }   

    //listen with backlog =10
    int backlog=10;

    int listenvar=listen(tracker_fd,backlog);
    if(listenvar<0){
        perror("cant listen");
        exit(EXIT_FAILURE);
    }

    //accepting to listen
    vector<thread>threadvec;
    while(true){

        int acceptvar=accept(tracker_fd,(struct sockaddr*)&addr,(socklen_t*)(&addrlen));
        if(acceptvar<0){
            perror("cant accpt");
            exit(EXIT_FAILURE);
        }
        thread th(funct_clients,acceptvar);
        threadvec.push_back(move(th));
        //this work to do in thread function which handles all the clients  
        // int valread=read(acceptvar,buffer,1024);
        // printf("%s\n",buffer);
        // send(acceptvar,message,strlen(message),0);
        // printf("hello sent to client\n");

    }
    for(thread &th:threadvec){
        if(th.joinable())
            th.join();
    }


    // shutdown(tracker_fd,SHUT_RDWR); used to block connection rdwr is like one way or other
    //close fully destroy the connections;
    // close(tracker_fd);  
    return 0;
}   