#include<bits/stdc++.h>
#include<sys/stat.h>
#include<fcntl.h>
using namespace std;

// vector<string> converttostring(string str){
//     vector<string>vecstr;
//     string temp="";

//     for(int i=0;i<str.size();i++){
//         if(str[i]!=' '){
//             temp=temp+str[i];
//         }
//         else{
//             vecstr.push_back(temp);
//             temp="";
//         }
//     }
//     vecstr.push_back(temp);
//     cout<<str;
//     return vecstr;
// }

// bool containsNearbyDuplicate(vector<int>& nums, int k) {
//         unordered_map<int,int>m;
//         // cout<<nums.size()<<" ";
//         for(int i=0;i<nums.size();i++){
//             if(m.count(nums[i])){
//                 if(abs(m[nums[i]]-i)<=k){
//                     return true;
//                 }
//             }
//             m[nums[i]]=i;
            
//             for(auto it:m){
//                 cout<<it.first<<" "<<it.second<<endl;
//             }
//         }
//         return false;
// }




vector<string> strtovecofstr(string str){
    vector<string>vecstr;
    string temp="";

    for(int i=0;i<str.size();i++){
        if(str[i]!=' '){
            temp=temp+str[i];
        }
        else{
            vecstr.push_back(temp);
            temp="";
        }
    }
    vecstr.push_back(temp);
    return vecstr;
}

string get_file_name(string s){
    string var="";
    for(auto &i:s){
        if(i=='/'){
            var="";
        }
        else{
            var=var+i;
        }
    }
    return var;
}



int main(){

    // vector<int>nums;
    // nums.push_back(1); 
    // nums.push_back(2);
    // nums.push_back(3);   
    // nums.push_back(1); 

    // cout<<containsNearbyDuplicate(nums,3)<<endl;


/*////mapwork of upload file;
*/
unordered_map<string,unordered_map <string,unordered_map<string,vector<string>>>> fileupload_map;

    vector<string>filedetails_of_member;
    unordered_map<string,vector<string>>user_to_filedetails;
    unordered_map<string,unordered_map<string,vector<string>>>file_to_inside;






    string ip="0.0.0.0";
    string port="9000";
    string filesize="16";
    string filelocation="a.txt";

    struct stat fileStat;


    char buff[255]={0};
    char *res=realpath(filelocation.c_str(),buff);
    filelocation=string(buff);
    cout<<string(buff)<<endl<<endl;
    
    stat(filelocation.c_str(),&fileStat);
    filesize=to_string((int)(fileStat.st_size));

    filedetails_of_member.push_back(ip);
    filedetails_of_member.push_back(port);
    filedetails_of_member.push_back(filesize);
    filedetails_of_member.push_back(filelocation);
    user_to_filedetails["m1"]=filedetails_of_member;
    filedetails_of_member.clear();

    cout<<endl<<endl<<get_file_name(filelocation)<<endl<<endl;



    //f1 m2 details
    ip="1.0.0.0";
    port="1000";
    filesize="18";
    filelocation="b/b.txt";

    res=realpath(filelocation.c_str(),buff);
    filelocation=string(buff);
    stat(filelocation.c_str(),&fileStat);
    filesize=to_string((int)(fileStat.st_size));
    filedetails_of_member.push_back(ip);
    filedetails_of_member.push_back(port);
    filedetails_of_member.push_back(filesize);
    filedetails_of_member.push_back(filelocation);
    
    user_to_filedetails["m2"]=filedetails_of_member;
    filedetails_of_member.clear();

    file_to_inside["f1"]=user_to_filedetails;

    fileupload_map["g1"]=file_to_inside;

    for(auto gid:fileupload_map){
        
        for(auto file:gid.second){
            
            for(auto mid:file.second){
                cout<<gid.first<<" ";
                cout<<file.first<<" ";
                cout<<mid.first<<" ";
                for(auto data:mid.second){
                    cout<<data<<" ";
                }
                cout<<endl;
            }
        }
    }



/* map work of group mebers
    // unordered_map<string,unordered_set<string>>map;

    // unordered_set<string>s;
    // s.insert("1");
    // s.insert("2");
    // s.insert("3");
    // map["a"]=s;

    // for(auto i:map){
    //     for(auto k:i.second){
    //         cout<<k<<endl;
    //     }
    // }

    // if(map["a"].find("1")!=map["a"].end()){
    //     // cout<<"yes found\n";
    //     map["a"].erase("1");cout<<endl<<endl;


    // }

    // for (auto i:map){
    //     for (auto k:i.second){

    //     }
    // }

    // for(auto i:map){
    //     for(auto k:i.second){
    //         cout<<k<<endl;
    //     }
    // }
    //  1char buffer[1000];
    // scanf("%s",buffer);
    // vector<string>vec= converttostring(string(buffer));

    // cout<<endl;
    // for(auto i:vec){
    //     cout<<i<<" ";
    // 1}

*/



    /* adding port ip to filename


    printf("enter data to buffer\n");
    char buffer2[1000]={0};
    scanf("%[^\n]s",buffer2);
    // cout<<string(buffer2)<<endl<<flush;

    vector<string> commands=strtovecofstr(string(buffer2));
    cout<<endl;

    string ip="0.0.0.0";
    string port="8000";
    string ip_port=ip+":"+port;
    // cout<<ip_port<<endl;
    // for(auto i:commands){
    //     cout<<i<<" ";
    // }
    cout<<endl;

    string f=string(buffer2)+" "+ string(ip_port);

    snprintf(buffer2,1000,f.c_str());

    cout<<string(buffer2)<<endl;

        */

    return 0;
}
